export default function Terms() {
  return (
    <main className="container py-12 prose prose-invert max-w-none">
      <h1>Terms</h1>
      <p>By using this site, you agree to the terms of service. No chargebacks for delivered content. Be nice.</p>
    </main>
  )
}
