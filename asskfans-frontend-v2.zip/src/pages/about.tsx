export default function About() {
  return (
    <main className="container py-12 prose prose-invert max-w-none">
      <h1>About</h1>
      <p>AsskFans is the official tipping spot for the Ass King. Fast, secure, and simple.</p>
    </main>
  )
}
