export default function Privacy() {
  return (
    <main className="container py-12 prose prose-invert max-w-none">
      <h1>Privacy</h1>
      <p>We process payments with Stripe and (optionally) PayPal. We store only what's necessary to operate the service.</p>
    </main>
  )
}
